package com.ty.project_1.service;

import com.ty.project_1.ConversionResponse;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class CurrencyConverterService {
    
    // Comprehensive exchange rates
    private static final Map<String, Double> EXCHANGE_RATES = Map.ofEntries(
        Map.entry("USD_TO_EUR", 0.93),
        Map.entry("USD_TO_GBP", 0.80),
        Map.entry("USD_TO_INR", 83.25),
        Map.entry("USD_TO_JPY", 147.50),
        Map.entry("USD_TO_AUD", 1.52),
        Map.entry("USD_TO_CAD", 1.35),
        Map.entry("EUR_TO_USD", 1.08),
        Map.entry("EUR_TO_GBP", 0.86),
        Map.entry("EUR_TO_INR", 89.50),
        Map.entry("GBP_TO_USD", 1.25),
        Map.entry("GBP_TO_EUR", 1.16),
        Map.entry("GBP_TO_INR", 105.75),
        Map.entry("INR_TO_USD", 0.012),
        Map.entry("INR_TO_EUR", 0.011),
        Map.entry("INR_TO_GBP", 0.0095)
    );
    
    
    public ConversionResponse convertCurrency(String fromCurrency, String toCurrency, Double amount) {
        // Validate input
        if (fromCurrency == null || toCurrency == null || amount == null) {
            throw new IllegalArgumentException("All parameters are required");
        }
        
        if (amount < 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
        
        // Same currency conversion
        if (fromCurrency.equalsIgnoreCase(toCurrency)) {
            return new ConversionResponse(amount, fromCurrency, toCurrency, amount, 1.0);
        }
        
        String key = fromCurrency.toUpperCase() + "_TO_" + toCurrency.toUpperCase();
        
        // Direct conversion
        if (EXCHANGE_RATES.containsKey(key)) {
            Double rate = EXCHANGE_RATES.get(key);
            Double convertedAmount = round(amount * rate, 2);
            return new ConversionResponse(amount, fromCurrency, toCurrency, convertedAmount, rate);
        }
        
        // Reverse conversion
        String reverseKey = toCurrency.toUpperCase() + "_TO_" + fromCurrency.toUpperCase();
        if (EXCHANGE_RATES.containsKey(reverseKey)) {
            Double reverseRate = EXCHANGE_RATES.get(reverseKey);
            Double rate = round(1.0 / reverseRate, 6);
            Double convertedAmount = round(amount * rate, 2);
            return new ConversionResponse(amount, fromCurrency, toCurrency, convertedAmount, rate);
        }
        
        // USD as base currency for cross conversion
        String fromToUSD = fromCurrency.toUpperCase() + "_TO_USD";
        String usdToTarget = "USD_TO_" + toCurrency.toUpperCase();
        
        if (EXCHANGE_RATES.containsKey(fromToUSD) && EXCHANGE_RATES.containsKey(usdToTarget)) {
            Double toUSDRate = EXCHANGE_RATES.get(fromToUSD);
            Double fromUSDRate = EXCHANGE_RATES.get(usdToTarget);
            Double rate = round(toUSDRate * fromUSDRate, 6);
            Double convertedAmount = round(amount * rate, 2);
            return new ConversionResponse(amount, fromCurrency, toCurrency, convertedAmount, rate);
        }
        
        throw new RuntimeException("Conversion rate not available for " + fromCurrency + " to " + toCurrency);
    }
    
   
    public List<String> getAvailableCurrencies() {
        return Arrays.asList("USD", "EUR", "GBP", "INR", "JPY", "AUD", "CAD", "CHF", "CNY", "SGD");
    }
    
    
    public Map<String, Double> getFeaturedRates() {
        Map<String, Double> featured = new LinkedHashMap<>();
        featured.put("USD to EUR", EXCHANGE_RATES.get("USD_TO_EUR"));
        featured.put("USD to GBP", EXCHANGE_RATES.get("USD_TO_GBP"));
        featured.put("USD to INR", EXCHANGE_RATES.get("USD_TO_INR"));
        featured.put("EUR to USD", EXCHANGE_RATES.get("EUR_TO_USD"));
        featured.put("GBP to USD", EXCHANGE_RATES.get("GBP_TO_USD"));
        featured.put("INR to USD", EXCHANGE_RATES.get("INR_TO_USD"));
        return featured;
    }
    
    
    private Double round(Double value, int places) {
        if (places < 0) throw new IllegalArgumentException();
        
        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }
}