package com.ty.project_1;

public class ConversionResponse {
    
    private Double originalAmount;
    private String fromCurrency;
    private String toCurrency;
    private Double convertedAmount;
    private Double exchangeRate;
    private String message;
    private Boolean success;
    
    // Default constructor
    public ConversionResponse() {}
    
    // Success constructor
    public ConversionResponse(Double originalAmount, String fromCurrency, 
                             String toCurrency, Double convertedAmount, 
                             Double exchangeRate) {
        this.originalAmount = originalAmount;
        this.fromCurrency = fromCurrency;
        this.toCurrency = toCurrency;
        this.convertedAmount = convertedAmount;
        this.exchangeRate = exchangeRate;
        this.message = "Conversion successful";
        this.success = true;
    }
    
    // Error constructor (used in controller)
    public ConversionResponse(String message) {
        this.message = message;
        this.success = false;
    }
    
    // Getters and Setters (all the getters and setters from previous code)
    public Double getOriginalAmount() {
        return originalAmount;
    }
    
    public void setOriginalAmount(Double originalAmount) {
        this.originalAmount = originalAmount;
    }
    
    public String getFromCurrency() {
        return fromCurrency;
    }
    
    public void setFromCurrency(String fromCurrency) {
        this.fromCurrency = fromCurrency;
    }
    
    public String getToCurrency() {
        return toCurrency;
    }
    
    public void setToCurrency(String toCurrency) {
        this.toCurrency = toCurrency;
    }
    
    public Double getConvertedAmount() {
        return convertedAmount;
    }
    
    public void setConvertedAmount(Double convertedAmount) {
        this.convertedAmount = convertedAmount;
    }
    
    public Double getExchangeRate() {
        return exchangeRate;
    }
    
    public void setExchangeRate(Double exchangeRate) {
        this.exchangeRate = exchangeRate;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public Boolean getSuccess() {
        return success;
    }
    
    public void setSuccess(Boolean success) {
        this.success = success;
    }
    
    @Override
    public String toString() {
        return "ConversionResponse{" +
                "originalAmount=" + originalAmount +
                ", fromCurrency='" + fromCurrency + '\'' +
                ", toCurrency='" + toCurrency + '\'' +
                ", convertedAmount=" + convertedAmount +
                ", exchangeRate=" + exchangeRate +
                ", message='" + message + '\'' +
                ", success=" + success +
                '}';
    }
}