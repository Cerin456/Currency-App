package com.ty.project_1.controller;

import com.ty.project_1.ConversionRequest;
import com.ty.project_1.ConversionResponse;
import com.ty.project_1.service.CurrencyConverterService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping // <-- optional, but good practice to group controller mappings
public class CurrencyConverterController {

    private final CurrencyConverterService currencyService;

    // ✅ Use constructor injection (recommended in Spring Boot)
    @Autowired
    public CurrencyConverterController(CurrencyConverterService currencyService) {
        this.currencyService = currencyService;
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("pageTitle", "CurrencyConverter Pro - Home");
        model.addAttribute("featuredRates", currencyService.getFeaturedRates());
        model.addAttribute("currencies", currencyService.getAvailableCurrencies());
        return "home"; // ✅ make sure you have "home.html" (your template is Home.html → rename to lowercase)
    }

    @GetMapping("/convert")
    public String convertPage(Model model) {
        model.addAttribute("pageTitle", "Convert Currency - CurrencyConverter Pro");
        model.addAttribute("currencies", currencyService.getAvailableCurrencies());
        model.addAttribute("conversionRequest", new ConversionRequest());
        return "convert"; // ✅ must match convert.html in /templates
    }

    @PostMapping("/convert")
    public String convertCurrency(
            @Valid @ModelAttribute("conversionRequest") ConversionRequest conversionRequest,
            BindingResult bindingResult,
            Model model) {

        model.addAttribute("pageTitle", "Convert Currency - CurrencyConverter Pro");
        model.addAttribute("currencies", currencyService.getAvailableCurrencies());

        if (bindingResult.hasErrors()) {
            model.addAttribute("error", "Please correct the errors in the form");
            return "convert";
        }

        try {
            ConversionResponse response = currencyService.convertCurrency(
                    conversionRequest.getFromCurrency(),
                    conversionRequest.getToCurrency(),
                    conversionRequest.getAmount()
            );

            model.addAttribute("conversionResponse", response);
            model.addAttribute("success", true);
            model.addAttribute("conversionRequest", conversionRequest);

        } catch (Exception e) {
            model.addAttribute("error", "Conversion failed: " + e.getMessage());
            model.addAttribute("conversionRequest", conversionRequest);
        }

        return "convert";
    }

    @PostMapping("/api/convert")
    @ResponseBody
    public ConversionResponse convertCurrencyApi(@Valid @RequestBody ConversionRequest request) {
        try {
            return currencyService.convertCurrency(
                    request.getFromCurrency(),
                    request.getToCurrency(),
                    request.getAmount()
            );
        } catch (Exception e) {
            return new ConversionResponse(e.getMessage());
        }
    }

    @GetMapping("/about")
    public String about(Model model) {
        model.addAttribute("pageTitle", "About - CurrencyConverter Pro");
        return "about"; // ✅ must match about.html in /templates
    }

    @GetMapping("/api/currencies")
    @ResponseBody
    public Map<String, Object> getCurrencies() {
        Map<String, Object> response = new HashMap<>();
        response.put("currencies", currencyService.getAvailableCurrencies());
        response.put("count", currencyService.getAvailableCurrencies().size());
        return response;
    }

    @GetMapping("/api/rates")
    @ResponseBody
    public Map<String, Object> getRates() {
        Map<String, Object> response = new HashMap<>();
        response.put("featuredRates", currencyService.getFeaturedRates());
        response.put("timestamp", java.time.LocalDateTime.now().toString());
        return response;
    }
}
